function multi(j,k) {
    console.log(j*k);
    
}multi(9,8)

function subtr(p,q) {
    console.log(p-q);
    
}subtr(9,2,4,5)

function div(a,z) 
{
    console.log(a/z)
    
}div(10)

function sum(u,p) {
    console.log(u+p);
    
}sum()