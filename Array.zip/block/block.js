{
    var a=40
    function add(a,b) {
        return a+b
        
    }
    var a=10
    var b=40
    var a=40
    let d=3123
    const f=4.444
    console.log(a);
    console.log(b);
    console.log(d);
    console.log(f);
    console.log(add(5,8));
}
