function rest(a,b,...c){

    console.log(a,b,c);

}
    rest(78,90,56,67,78,89)