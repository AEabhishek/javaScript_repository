// var w=98;

do {


  
    console.log("value is harsh")
   var w=90

    
} while (w<=50);