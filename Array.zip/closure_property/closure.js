var my_dept = "Mechanical Engineer"
    // console.log(my_dept);

function my_subject()
{
    

          var subject="Thermo Dynamics"

      function my_author()
         {
         var author= "R S KHURMI"

           console.log(author);
           console.log(subject);
           console.log(my_dept);
           }my_author()
           

  



}my_subject()


