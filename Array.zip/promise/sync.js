
// async function sync() {
//     console.log("start");

// var p=new Promise((resolve, reject)=>{
//     setTimeout(() => {
//         resolve("in progress")
//     },2000);
// })

// await p.then((msg)=> {console.log(msg);}).catch((msg)=>{console.log(msg);})

// console.log("end")

// }
// sync()



// console.log("login");

// setTimeout(()=>{
//     console.log("it is a setTimeout method1");
// },1000)

// setTimeout(()=>{
//     console.log("it is a setTimeout method3");
// },3000)

// setTimeout(()=>{
//     console.log("it is a setTimeout method2");
// },2000)

// console.log("logout");



// function f1(){
//     console.log("function 1");

// }
// function f2(){
//     console.log("function 2");
//     f1()
// }
// function f3(){
//     console.log("function 3");
//     f2()
// }
// f3()