class good{
    constructor(colddrink,hotdrink,icedrink)
    {
        this.colddrink =colddrink
        this.hotdrink=hotdrink
        this.icedrink=icedrink
    }
    



}
var drink = new good("pepsi","Coffee","ICEburg")
console.log(drink);
