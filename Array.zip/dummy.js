// var hubli ={
//     f_choice : "BVB College",
//     s_choice : "Nehru Ground",
    
//     my_fav : function() {
//     console.log("MY FAVOURITE PLACE IS" + this.f_choice);
    
//     }
//     }
    
//     var bangalore ={
//     f_choice : "yalahanka",
//     s_choice : "mysuru road",
    
//     My_family : function()
//     {
//         console.log("MY FAMILY LIVES"+this.f_choice);
    
//     }
//     }
    
//     function contact(string1,string2)
//     {
//     console.log(string1+" "+this.f_choice+" "+string2);
    
//     }
    
//     hubli.my_fav.call(bangalore)
//     contact.call(hubli,"goodevening","welcome")
//     contact.call(bangalore,"goodevening","welcome")



//   var  add = (a,b)=> {
// return a+b;
// }
// add(3,4)



// var gum = (a,b)=>{
//     if (a>b)
//     console.log("value is more");
//     else
//     return "value is less"
//     }
//     console.log(gum(6,7));