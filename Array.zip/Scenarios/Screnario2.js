var a=56
function sum(l,u) {    
   {
       function gold(x,y) 
       {
           var d=78
           let e=90
           const p=3435
           console.log(x+y);
           console.log(d);
           console.log(e);
           console.log(p);  
       }gold(6,7)
   }
    
                 
  return sum(l+u)
} 
console.log(sum(8,9));      

// Global variable
// a

// local
// l,u,x,y,d

//script
//e,p
// block

