var g=5678

if (g<6000) {

    console.log("Given number is perfect");
    
} else {

    console.log("Given number is not enough");
    
}