var first_name = "IRON MAN"
var last_name = "SUPER MAN"
console.log(`hello i am ${first_name} ${last_name} good morning`)
console.log(`hello
i am
new ${first_name}
and new
${last_name}
bye`);