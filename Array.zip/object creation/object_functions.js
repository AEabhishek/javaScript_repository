function gold(mango, orange, pineaple, greenberry)
{
    this.mango = mango
    this.orange = orange
    this.pineaple = pineaple
    this.greenberry = greenberry

}
var rates = new gold (45,98,23,78)

console.log(rates.mango);