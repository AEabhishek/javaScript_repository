var a=78
var b=56
let c=789
const d=7.1234
console.log(a);
console.log(b);
console.log(c);