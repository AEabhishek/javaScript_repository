//object destructuring
 var fruit={f_choice:"tejaswi"}

//  console.log(fruit.f_choice);

   //  let {f_choice:fname} = fruit
   //  console.log(fname)
    
    let {f_choice} = fruit
    console.log(f_choice)
    
   //  let fname= fruit.f_choice
   //  console.log(fname)

   
