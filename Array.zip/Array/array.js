//type=1
//var Array1=new Array("king",56,"crack",0.78,true,undefined)
//console.log(Array1);

//in this method we are not getting output 56 instead its showing 56empty items to overcome we use type2
//var arr2=new Array(56)
//console.log(arr2);


//type2
var arr3=[56]
console.log(arr3);

var arr4=[67,89,0.88,4532]
console.log(arr4);