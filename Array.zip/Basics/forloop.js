var f=89
var f=90
for(var f=90; f<=90;)
{
    console.log("good");
    var f=190;

}

