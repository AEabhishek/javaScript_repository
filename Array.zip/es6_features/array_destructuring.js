let arr4=[78,90,89,67,56]

// let x=arr4[1]
// let y=arr4[3]
// console.log(x,y);


// let [x,y] = arr4
// console.log(x,y);

// let[a,b,c] =arr4
// console.log(a,b,c);


let [t,,,,p]=arr4
console.log(t,p);