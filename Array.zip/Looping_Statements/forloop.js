
var arr2=[0.88,"JSON",true,99]

for (var index = 0; index < arr2.length; index++) {
    console.log(arr2[index]);
    
}