
var arr3=[56,"node",true,0.5555]
var index=0
for (var index in arr3) {
    if (index<2) {
        console.log("log will be stopped");
        index++
       
        
    }
}
for (const key in object) {
    if (Object.hasOwnProperty.call(object, key)) {
        const element = object[key];
        
    }
}