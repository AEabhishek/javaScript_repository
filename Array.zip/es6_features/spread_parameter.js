// var arr2=[89,90,78,67]
// var arr3=[34,45,56]
// console.log(...arr2,...arr3);


// var arr4=[90,89,78,56]
// var arr6=[...arr4,60]
// console.log(arr6);


// const pi={
//     f_name:"gravitation",
//     f_choice:"newton"
// }
// const tita = {
//     f_name :"sine",

//     f_choice : "cosine"


// }
// const pr={...pi,...tita}

// console.log(pr);// value will be overrides the second function



const terra={
    f_choice : "rose",
    f_name :"lilli"
}
const f={...terra}// here spread parameter function take place
console.log(f);



