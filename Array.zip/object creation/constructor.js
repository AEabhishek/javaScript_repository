 class repo {

    constructor(mahesh,ramesh,raju)
    {
        this.mahesh = mahesh
        this.ramesh = ramesh
        this.raju = raju
    }

}    
    
  
var java=new repo(45,76,90)
console.log(java);