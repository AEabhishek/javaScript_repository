/*var g="folder"
console.log(g);

var jar=false
console.log(!jar);

var e=99.92345
console.log(e);

var s="open"
console.log(s);*/

var a=1
console.log(typeof(a));

var r="good"
console.log(typeof(r));

var t=false
console.log(typeof(t));

var j='javaselenium'
console.log(typeof(j));

var o;
console.log(typeof(o));

var f=56
f=78
console.log(f);

let p=56
let k=78
console.log(k);

let q=90
q="gate"
console.log(q);

