var arr1=[88,"Ranger",0.3456,false]
var index=0;
do{
    console.log("Looping happens");
    index++
}while (index<2) 


do {
    
} while (condition);