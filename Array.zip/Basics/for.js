let s=78
s=90
console.log(s);
if (s=90) {
    console.log("yes is 90");
    
} else
 {
     console.log("no its not");
    
}