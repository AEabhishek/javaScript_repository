var s=400

if (s<500) {

    console.log("number is less than 500");
    
} 
else if (s=500) {
    console.log("number is more than 500");

    
} 
else (s<=300)
{
    console.log("number is equal to 300");
}