//  function  get (a,b){
//     console.log(a+b)
//  }get(6,5)//11

//  function sum (b,c)
//  {
//      console.log(b+c);
//  }
//  sum(8)//nan

// function plus(h,j=9){
// console.log(h+j);
// }
// plus(7)    //16

// function min(i,o=1){
//     console.log(i+o);
// }min(8,9)    //17

class larg{
    constructor(a,b){
        console.log(a+b);

    }
    
}
let r=new larg(5,7)  //12

