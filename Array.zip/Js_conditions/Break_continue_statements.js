var arr3=[56,"node",true,0.5555]
for (var index=0; index<arr3.length; index++) {
    if (index<2) {
        console.log("log will be stopped");
        continue
        console.log("hello");
       
        
    }
    console.log(arr3+" "+ index);
}