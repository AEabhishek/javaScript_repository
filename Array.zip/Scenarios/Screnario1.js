var d=12
function add(d,e)
 {
    {
        let f=78
        const j=90
        console.log(j);
        console.log(f);
          d+e
        
    }
    {
        let p=67
        const k=89
        console.log(p);
        console.log(k);

    }
      
}
add(7,9)


// global
// d

// Local
// d,e

// block
// p,k,f,j





