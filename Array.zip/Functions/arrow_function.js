//var op=(a,b)=> 
//{
    //return a+b
//}
//console.log(op(8,9));


var sh=(c,d)=>
{
    if(c>d)
    return  "c is greater"
    else
    return "d is greater"
}
console.log(sh(8,9));
