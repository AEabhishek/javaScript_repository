(function (h,o) {
    console.log(h+o);
})(6,7)