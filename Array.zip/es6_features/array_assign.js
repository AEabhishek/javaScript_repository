
var arr4=[89,78,67,56,45]

//case:01
let[x,y]=arr4
console.log(x,y)//===========>89,78

//case:02
let[a,b,c]=arr4
console.log(a,b,c)//===========>89,78,67

//case:03
let e=arr4[0]
let r=arr[3]
console.log(e,r)//============>89,56


//case:04
let [g,,,z]=arr4
console.log(y,z)//========>89,56