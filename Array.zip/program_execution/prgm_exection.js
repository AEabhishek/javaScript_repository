
var a=70
function add(a,b) 
{
    var a=10
    var b=20
    let e=45
const d=89
console.log(a+b);
console.log(a);
console.log(b);
console.log(e);
console.log(d);
}
add(5,6)