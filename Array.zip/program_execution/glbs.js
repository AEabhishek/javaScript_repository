//global
// var a=10
// var b=20
// var a=30
// console.log(a);
//  console.log(b);

// var i=10============================>global variables=i,j  and script=b&c
// var j=20
// function soper(a,b) {
//     return a+b==============================>local
    
// }soper(6,5)
// var a=10
// const b=20
// const c=30
// console.log(a);
// console.log(b);
// console.log(c);

//script
// var r=67
// var a=78
// let b=90
// const z=56
// console.log(a);
// console.log(b);
// console.log(c);

var r=89
// //block
{
    var a=78
    let b=90
    const g=56
    console.log(a);
    console.log(b);
    console.log(g);

}
