var arr5=[66,"moon",9.0,false]

for (var index of arr5) {
    console.log("looping is failed");
    
    
}
for (const iterator of object) {
    
}