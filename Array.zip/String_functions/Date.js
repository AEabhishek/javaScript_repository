var d = new Date();

// console.log(d);
var date = d.toDateString()
console.log(date);
console.log(date.split(" ")[0]);//M
console.log(date.split(" ")[0]);//MON


// console.log(d.toDateString());
// console.log(d.getDate());
// console.log(d.getDay());
// console.log(d.getFullYear());






