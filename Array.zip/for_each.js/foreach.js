
var arr=[56,78,09,89,56]

arr.forEach((element,index,arr) => {
    console.log((index+"------"+element+"------"+arr))
    console.log(arr[index]);
    
// });

// for (let index = 0; index < arr.length; index++) {
//     console.log(arr[index]);
    
// }

// for (var index in arr) {
//     if (index<3) {
//         index++

//           console.log(arr);
        
//     }
// }


// for (var index of arr) {
//     console.log(arr);
    
// }

