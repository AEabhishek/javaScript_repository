var a=10
var b=70
function sample()
{
console.log(a);
console.log(b);
var b=200

}