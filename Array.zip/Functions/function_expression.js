var sap = function(a,b) {
    console.log(a+b);
    
}
sap(4,5)

