var arr=["rto",67,98,098,123]

var index=0;

while (index < 1) {
    console.log("looping");
    index++

    
}