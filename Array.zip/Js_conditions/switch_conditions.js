
var d=700;

switch (d) {
    case 500:
        {
            console.log("number is good");
        }
        break;
        case 400:
        {
            console.log("number is bad");
        }
        break;

        

    default:
        console.log("number is failed");
        break;
}